
package net.mcreator.toendallplushies.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.toendallplushies.procedures.PlushyPoseProcedure;
import net.mcreator.toendallplushies.procedures.PlushyHugProcedure;

public class StartshowBeachPlushBlock extends Block implements SimpleWaterloggedBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

	public StartshowBeachPlushBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOL).strength(0.8f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(WATERLOGGED, false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(4, 8, 1, 12, 16, 9), box(3.5, 7.5, 0.5, 12.5, 16.5, 9.5), box(5, 0, 2, 11, 8, 8), box(4.5, -0.5, 1.5, 11.5, 8.5, 8.5), box(4.15224, 0, 7.76537, 7.15224, 3, 13.76537),
					box(3.72836, -0.5, 7.64805, 7.72836, 3.5, 14.64805), box(1.45253, 5, 2.69763, 7.45253, 8, 5.69763), box(0.95253, 4.5, 2.19763, 7.95253, 8.5, 6.19763), box(8.77164, 0, 8.14805, 11.77164, 3, 14.14805),
					box(8.27164, -0.5, 7.64805, 12.27164, 3.5, 14.64805), box(8.54747, 5, 4.69763, 14.54747, 8, 7.69763), box(8.04747, 4.5, 4.19763, 15.04747, 8.5, 8.19763));
			case NORTH -> Shapes.or(box(4, 8, 7, 12, 16, 15), box(3.5, 7.5, 6.5, 12.5, 16.5, 15.5), box(5, 0, 8, 11, 8, 14), box(4.5, -0.5, 7.5, 11.5, 8.5, 14.5), box(8.84776, 0, 2.23463, 11.84776, 3, 8.23463),
					box(8.27164, -0.5, 1.35195, 12.27164, 3.5, 8.35195), box(8.54747, 5, 10.30237, 14.54747, 8, 13.30237), box(8.04747, 4.5, 9.80237, 15.04747, 8.5, 13.80237), box(4.22836, 0, 1.85195, 7.22836, 3, 7.85195),
					box(3.72836, -0.5, 1.35195, 7.72836, 3.5, 8.35195), box(1.45253, 5, 8.30237, 7.45253, 8, 11.30237), box(0.95253, 4.5, 7.80237, 7.95253, 8.5, 11.80237));
			case EAST -> Shapes.or(box(1, 8, 4, 9, 16, 12), box(0.5, 7.5, 3.5, 9.5, 16.5, 12.5), box(2, 0, 5, 8, 8, 11), box(1.5, -0.5, 4.5, 8.5, 8.5, 11.5), box(7.76537, 0, 8.84776, 13.76537, 3, 11.84776),
					box(7.64805, -0.5, 8.27164, 14.64805, 3.5, 12.27164), box(2.69763, 5, 8.54747, 5.69763, 8, 14.54747), box(2.19763, 4.5, 8.04747, 6.19763, 8.5, 15.04747), box(8.14805, 0, 4.22836, 14.14805, 3, 7.22836),
					box(7.64805, -0.5, 3.72836, 14.64805, 3.5, 7.72836), box(4.69763, 5, 1.45253, 7.69763, 8, 7.45253), box(4.19763, 4.5, 0.95253, 8.19763, 8.5, 7.95253));
			case WEST -> Shapes.or(box(7, 8, 4, 15, 16, 12), box(6.5, 7.5, 3.5, 15.5, 16.5, 12.5), box(8, 0, 5, 14, 8, 11), box(7.5, -0.5, 4.5, 14.5, 8.5, 11.5), box(2.23463, 0, 4.15224, 8.23463, 3, 7.15224),
					box(1.35195, -0.5, 3.72836, 8.35195, 3.5, 7.72836), box(10.30237, 5, 1.45253, 13.30237, 8, 7.45253), box(9.80237, 4.5, 0.95253, 13.80237, 8.5, 7.95253), box(1.85195, 0, 8.77164, 7.85195, 3, 11.77164),
					box(1.35195, -0.5, 8.27164, 8.35195, 3.5, 12.27164), box(8.30237, 5, 8.54747, 11.30237, 8, 14.54747), box(7.80237, 4.5, 8.04747, 11.80237, 8.5, 15.04747));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, WATERLOGGED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(WATERLOGGED, flag);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor world, BlockPos currentPos, BlockPos facingPos) {
		if (state.getValue(WATERLOGGED)) {
			world.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, facing, facingState, world, currentPos, facingPos);
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		PlushyPoseProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		PlushyHugProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}
