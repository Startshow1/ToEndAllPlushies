
package net.mcreator.toendallplushies.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.toendallplushies.procedures.PlushyPoseProcedure;
import net.mcreator.toendallplushies.procedures.PlushyHugProcedure;

public class DressStevePlushBlock extends Block implements SimpleWaterloggedBlock {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

	public DressStevePlushBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOL).strength(0.8f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(WATERLOGGED, false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return state.getFluidState().isEmpty();
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(4, 8, 6, 12, 16, 14), box(3.5, 7.5, 5.5, 12.5, 16.5, 14.5), box(5, 0, 7, 11, 8, 13), box(4.5, -0.5, 6.5, 11.5, 8.5, 13.5), box(8.84776, 0, 1.23463, 11.84776, 3, 7.23463),
					box(8.27164, -0.5, 0.35195, 12.27164, 3.5, 7.35195), box(8.54747, 5, 9.30237, 14.54747, 8, 12.30237), box(8.04747, 4.5, 8.80237, 15.04747, 8.5, 12.80237), box(4.22836, 0, 0.85195, 7.22836, 3, 6.85195),
					box(3.72836, -0.5, 0.35195, 7.72836, 3.5, 7.35195), box(1.45253, 5, 9.30237, 7.45253, 8, 12.30237), box(0.95253, 4.5, 8.80237, 7.95253, 8.5, 12.80237));
			case NORTH -> Shapes.or(box(4, 8, 2, 12, 16, 10), box(3.5, 7.5, 1.5, 12.5, 16.5, 10.5), box(5, 0, 3, 11, 8, 9), box(4.5, -0.5, 2.5, 11.5, 8.5, 9.5), box(4.15224, 0, 8.76537, 7.15224, 3, 14.76537),
					box(3.72836, -0.5, 8.64805, 7.72836, 3.5, 15.64805), box(1.45253, 5, 3.69763, 7.45253, 8, 6.69763), box(0.95253, 4.5, 3.19763, 7.95253, 8.5, 7.19763), box(8.77164, 0, 9.14805, 11.77164, 3, 15.14805),
					box(8.27164, -0.5, 8.64805, 12.27164, 3.5, 15.64805), box(8.54747, 5, 3.69763, 14.54747, 8, 6.69763), box(8.04747, 4.5, 3.19763, 15.04747, 8.5, 7.19763));
			case EAST -> Shapes.or(box(6, 8, 4, 14, 16, 12), box(5.5, 7.5, 3.5, 14.5, 16.5, 12.5), box(7, 0, 5, 13, 8, 11), box(6.5, -0.5, 4.5, 13.5, 8.5, 11.5), box(1.23463, 0, 4.15224, 7.23463, 3, 7.15224),
					box(0.35195, -0.5, 3.72836, 7.35195, 3.5, 7.72836), box(9.30237, 5, 1.45253, 12.30237, 8, 7.45253), box(8.80237, 4.5, 0.95253, 12.80237, 8.5, 7.95253), box(0.85195, 0, 8.77164, 6.85195, 3, 11.77164),
					box(0.35195, -0.5, 8.27164, 7.35195, 3.5, 12.27164), box(9.30237, 5, 8.54747, 12.30237, 8, 14.54747), box(8.80237, 4.5, 8.04747, 12.80237, 8.5, 15.04747));
			case WEST -> Shapes.or(box(2, 8, 4, 10, 16, 12), box(1.5, 7.5, 3.5, 10.5, 16.5, 12.5), box(3, 0, 5, 9, 8, 11), box(2.5, -0.5, 4.5, 9.5, 8.5, 11.5), box(8.76537, 0, 8.84776, 14.76537, 3, 11.84776),
					box(8.64805, -0.5, 8.27164, 15.64805, 3.5, 12.27164), box(3.69763, 5, 8.54747, 6.69763, 8, 14.54747), box(3.19763, 4.5, 8.04747, 7.19763, 8.5, 15.04747), box(9.14805, 0, 4.22836, 15.14805, 3, 7.22836),
					box(8.64805, -0.5, 3.72836, 15.64805, 3.5, 7.72836), box(3.69763, 5, 1.45253, 6.69763, 8, 7.45253), box(3.19763, 4.5, 0.95253, 7.19763, 8.5, 7.95253));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, WATERLOGGED);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(WATERLOGGED, flag);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
	}

	@Override
	public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor world, BlockPos currentPos, BlockPos facingPos) {
		if (state.getValue(WATERLOGGED)) {
			world.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(world));
		}
		return super.updateShape(state, facing, facingState, world, currentPos, facingPos);
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		PlushyPoseProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		PlushyHugProcedure.execute(world, x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}
